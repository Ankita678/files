--drop table Booking cascade constraint;
--drop table Fare cascade constraint;

--drop sequence hibernate_sequence;
--create sequence hibernate_sequence START with 10 INCREMENT BY 1;

create database infy_cabs_db;
use infy_cabs_db;
create table Booking(
	booking_id int auto_increment,
	user_mobile BIGINT,
	source varchar(15),
	destination varchar(10),
	fare decimal(9,2),
	travel_date DATE,
	status CHAR NOT NULL,
	constraint pk_booking primary key(booking_id)
);
alter table booking auto_increment = 10;

create table Fare(
	fare_id int primary key,
	source varchar(15),
	destination varchar(15),
	fare int
);

insert into Fare values(1,'San Jose','Los Angles',340);
insert into Fare values(2,'San Francisco','San Jose',48);
insert into Fare values(3,'Los Angles','San Diego',120);
insert into Fare values(4,'Pheonix','Tucson',114);

insert into Booking values(1,9877766756,'San Jose','Los Angles',340,sysdate()+interval 2 day,'B');
insert into Booking values(2,8898766766,'San Francisco','San Jose',48,sysdate()+interval 4 day,'B');

commit;

select * from Fare;
select * from Booking;

