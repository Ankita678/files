package com.infy.api;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.infy.model.CabBooking;
import com.infy.service.BookingService;

@RestController
@RequestMapping(name="/booking")
public class CabBookingAPI {
	
	@Autowired
	private BookingService bookingService;
	
	@Autowired
	private Environment environment;

	@PostMapping(name="/{cabBooking}")
	public ResponseEntity<String> bookCab(@RequestBody CabBooking cabBooking) throws Exception {
		ResponseEntity<String> response = null;
		try{
			Integer bookingId = bookingService.bookCab(cabBooking);
			String success_message = environment.getProperty("API.BOOKING_SUCCESSFUL") + ": " + bookingId;
			response = new ResponseEntity<String>(success_message,HttpStatus.CREATED);
		}catch(Exception e){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,environment.getProperty(e.getMessage()),e);
		}
		
		return response;
	}

	@GetMapping(name="/{mobileNo}")
	public ResponseEntity<List<CabBooking>> getBookingDetails(@PathVariable Long mobileNo) throws Exception {
		ResponseEntity<List<CabBooking>> response = null;
		try{
			List<CabBooking> bookingList = bookingService.getBookingDetails(mobileNo);
			response = new ResponseEntity<List<CabBooking>>(bookingList,HttpStatus.OK);
		}catch(Exception e){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,environment.getProperty(e.getMessage()),e);
		}
		
		return response;

	}

	@PutMapping(name="/{bookingId}")
	public ResponseEntity<String> cancelBooking(@PathVariable Integer bookingId) throws Exception {
		ResponseEntity<String> response = null;
		try{
			bookingService.cancelBooking(bookingId);
			String message = environment.getProperty("API.BOOKING_CANCELLED");
			response = new ResponseEntity<String>(message,HttpStatus.OK);
		}catch(Exception e){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,environment.getProperty(e.getMessage()),e);
			
		}
		return response;
	}

}
